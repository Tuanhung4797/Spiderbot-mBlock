# Spiderbot
Firmware Arduino for Spider Robot
